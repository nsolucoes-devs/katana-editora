<?php
namespace PagarMe\Exceptions;

class InvalidJsonException extends \Exception
{
}
